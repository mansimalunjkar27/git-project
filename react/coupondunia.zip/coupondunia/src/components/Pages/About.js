import React from "react";

export const About = () => {
  return (
    <div>
      <h1>About</h1>
    </div>
  );
};