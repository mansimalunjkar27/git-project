import React from "react";


export const Home = () => {
  return (
    <div className="home">
      <h1>Welcome To Coupon Duniya </h1>
      <table className="align-item-center">
      <tr><img src="./Images/images2.jpg" alt=" " ></img>
      <img src="./Images/images3.jpg" alt=" "></img>
      <img src="./Images/images4.jpg" alt=" "></img></tr>
      <tr><img src="./Images/images3.jpg" alt=" "></img>
      <img src="./Images/images2.jpg" alt=" "></img>
      <img src="./Images/images4.jpg" alt=" "></img></tr>
      </table>
    </div>
  );
};