import React from "react";



export const Register = () => {
  return (
    <div>
      <h1>Register Here</h1>
    </div>
  );
};